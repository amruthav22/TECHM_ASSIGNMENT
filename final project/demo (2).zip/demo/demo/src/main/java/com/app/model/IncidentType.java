package com.app.model;

public enum IncidentType {
    DELAY, DAMAGE, INCORRECT_ADDRESS, VEHICLE_BREAKDOWN, OTHER
}
