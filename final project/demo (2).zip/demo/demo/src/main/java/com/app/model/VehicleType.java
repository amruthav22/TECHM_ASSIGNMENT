package com.app.model;

public enum VehicleType {
	 BIKE, SCOOTER, CAR, VAN, TRUCK
}
