package com.app.model;

public enum OrderStatus {
	 PENDING,
	    CONFIRMED,
	    ASSIGNED,
	    COMPLETED,
	    CANCELED
}
