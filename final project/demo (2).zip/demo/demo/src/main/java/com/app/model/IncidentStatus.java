package com.app.model;

public enum IncidentStatus {
    REPORTED, UNDER_REVIEW, RESOLVED
}
